# PuGo
By Lovenoor Aulck, building off the work of Dev Nambi

This page contains documentation for the Purple and Gold (PuGo) scholarship distribution project at the University of Washington (UW).

## About PuGo
The PuGo scholarships are merit-based scholarships given to domestic non-resident applicants to the UW. The scholarship is relatively new (i.e. < 5 years old) and is seen as a vehicle to boost out-of-state enrollment.

## (Brief) History of PuGo Modeling
PuGo modeling was initially outsourced to Human Capital Research Corporation (HCRC) of Evanston, Ill. for rather large sums of money. HCRC were provided requisite data from the UW Office of Enrollment Management (EM) and the UW Office of Financial Aid (FinAid) and, in turn, provided a student-by-student suggestion of awards to provide. They also provided additional analysis of the effect of their proposed scholarships but it does not seem that they did any historical analysis of scholarship effectiveness. HCRC were contracted for PuGo for at least 3 disbursement cycles (2015-2017).

After internal conversations, it was decided that shifting the work performed by HCRC in-house would be more beneficial to the UW, both financially and in terms of sustainability. More nuanced reasons behind this were many-fold but included: HCRC did not detail their approach in sufficient detail (i.e. used a black box), were believed to be using modeling techniques that could be improved upon (i.e. logistic regression), and were providing scholarship values that were skewed/biased towards certain demographics. In addition to this, it was understood that having the model be developed in-house would allow for greater transparency with results while allowing for more fine-tuning based on the needs of the campus. Ultimately, it was decided that Dev Nambi would begin developing PuGo models for scholarship allocation. The documentation for all the above or for Dev's work is not provided in this repo.

In October of 2017, Dev left the UW to pursue other career opportunities. I (Lovenoor Aulck) was brought on to carry over the work Dev started and ultimately establish a codebase that can be used for future iterations of PuGo disbursements. The documentation for this work is provided in this repo.

## Constraints on Model
### Original Constraints
The following constraints were posed on the model by EM and/or FinAid:
- The scholarship amounts must be merit-based. That is to say, students with higher academic profiles must receive an equal or greater offer than students with a lower academic profile.
- About half of admitted students should get a scholarship.
- The scholarship amounts must be round-dollar amounts to the nearest $1000.
- The scholarships should have a floor of $3000.
- The maximum award amount for the year should be three million dollars. The maximum offer amount should be about 10x this (i.e. approx. thirty million dollars)
### Revised Constraints (after meetings/discussions with EM and FinAid)
- Award about 50-70% of admitted students a scholarship. *Changed because it was seen that scholarships do seem to positively impact students' decisions to come to the UW.*
- The scholarship amounts must be round-dollar amounts to the nearest $100. *Changed because more granular amounts allows for more flexibility with optimizations. Ultimately, $300 increments were used because these would be more evenly distributed across the three quarters that the scholarhip is disbursed in a year.*
- The scholarships have no floor. *Ultimately, a floor of $3000 was kept with an experimental group receiving $1500 in scholarhips. This was because I did not feel comfortable extrapolating predictions of student enrollment with values less than $3000 when no scholarhips less than $3000 had been offered in the past.*
- There was some flexibility with the total award amount but it should not be much more than three million dollars. *This flexibility was in light of the fact that the incoming students were going to pay much more than their scholarship values in tuition as they were domestic non-residents, resulting in a overall surplus across time.*

## Approach Taken
### Related reading
The approach taken with this work is detailed in [this paper](https://www.sciencedirect.com/science/article/pii/S1877050915029841), though it should be noted that a neural network was not used and a gradient boosting model was instead. This and other papers of interest are as follow:
- [Student Yield Maximization Using Genetic Algorithm on a Predictive Enrollment Neural Network Model](https://www.sciencedirect.com/science/article/pii/S1877050915029841) 
- [Data Mining Application in Enrollment Management: A Case Study](https://pdfs.semanticscholar.org/b325/85581d3bb064b59f70f5d088b9602eece14d.pdf)
- [Decision support for university enrollment management: Implementation and experience](https://www.sciencedirect.com/science/article/pii/S016792360700053X)
The above papers are included in the Papers folder in the repo.

To better understand gradient boosting and genetic algorithms, the following could be of use:
- https://en.wikipedia.org/wiki/Gradient_boosting
- https://medium.com/mlreview/gradient-boosting-from-scratch-1e317ae4587d
- https://en.wikipedia.org/wiki/Genetic_algorithm
- https://towardsdatascience.com/introduction-to-genetic-algorithms-including-example-code-e396e98d8bf3

### Overview of Approach
The approach used in this project can be broken down into the following steps:
- Data cleaning: essentially prepping the data to be used
- Enrollment prediction: taking the clean data and generating a predictive model of enrollment
- Fund optimization: taking the predictive model and optimizing fund disbursement within constraints
- Generating outputs: taking the optimized fund disbursement and making final tweaks before delivery

## Description of code
The code for the project is organized in a manner similar to the overview provided above. The following folders are included in the repos:
- oldCode: contains older code versions. Should not be used unless looking at changes in code across time. Much of the code in here is from Dev Nambi.
- optimization: contains code used in the optimization step
- outputs: contains final outputs for disbursement
- papers: contains relevant reading
- predictions: contains code used in the prediction step
- preprocessing: contains code used in pre-processing

### General organization of scripts
The organization of the scripts is as follows (it should be noted that all scripts with a 'for paper' addition to them are used for work in the creation of a publication around PuGo. They are not detailed here and should be disregarded):
- preprocessing:
  - cleanData: used to clean historical PuGo data and generates clean data
- predictions:
  - hyperparameterTuning: an optional script that can be used to tune gradient boosting hyperparameters (optional)
  - predictEnrollment: a script that takes clean data and generates the gradient boosting model used in predictions. Outputs are passed to the 'forOpt' folder.
- optimization:
  - optimization: a script that takes outputs from predictEnrollment and performs the optimizations for scholarship amounts given constraints.
- outputs:
  - finalOutputs: a script used to take the results of the optimization and massage results for final deliverables.
